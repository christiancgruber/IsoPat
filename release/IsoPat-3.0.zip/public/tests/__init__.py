"""Tests for IsoPat package."""
