---
title: IsoPat
emoji: 🧪
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 5.9.1
app_file: app.py
pinned: false
license: mit
short_description: Isotope Pattern Deconvolution for Mass Spectrometry
---

# IsoPat 3.0

Determine relative amounts of isotope-labeled species from mass spectrometry data.

## Features

- Least-squares deconvolution algorithm
- Support for any isotope (D, ¹³C, ¹⁵N, ¹⁸O, etc.)
- Adjustable mass shift for different isotopes

## Installation

```bash
pip install isopat
```

## Links

- **PyPI:** https://pypi.org/project/isopat/
- **GitHub:** https://github.com/christiangruber1234/IsoPat

## Reference

Gruber et al. (2007) J. Org. Chem. 72, 5778-5783
https://doi.org/10.1021/jo070831o
