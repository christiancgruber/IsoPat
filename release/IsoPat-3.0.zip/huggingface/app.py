"""
IsoPat 3.0 - HuggingFace Gradio App
Isotope Pattern Deconvolution for Mass Spectrometry
"""

import gradio as gr
import numpy as np


def deconvolve(unlabeled_str, analyte_str, n_labels, mass_shift):
    """Deconvolve isotope pattern using least-squares optimization."""
    try:
        # Parse inputs
        unlabeled = np.array([float(x.strip()) for x in unlabeled_str.split(',')])
        analyte = np.array([float(x.strip()) for x in analyte_str.split(',')])
        n_labels = int(n_labels)
        mass_shift = int(mass_shift)

        # Normalize
        unlabeled_norm = unlabeled / np.max(unlabeled)
        analyte_norm = analyte / np.max(analyte)

        # Build pattern matrix
        n_pattern = len(unlabeled_norm)
        n_derivatives = n_labels + 1
        n_rows = n_pattern + n_labels * mass_shift

        A = np.zeros((n_rows, n_derivatives))
        for i in range(n_derivatives):
            shift = i * mass_shift
            A[shift:shift + n_pattern, i] = unlabeled_norm

        # Pad/truncate analyte
        if len(analyte_norm) < n_rows:
            analyte_norm = np.pad(analyte_norm, (0, n_rows - len(analyte_norm)))
        elif len(analyte_norm) > n_rows:
            analyte_norm = analyte_norm[:n_rows]

        # Solve least squares
        x, _, _, _ = np.linalg.lstsq(A, analyte_norm, rcond=None)
        x = np.clip(x, 0, None)
        x = x / np.sum(x)

        # Calculate metrics
        predicted = A @ x
        residuals = analyte_norm - predicted
        ss_res = np.sum(residuals ** 2)
        ss_tot = np.sum((analyte_norm - np.mean(analyte_norm)) ** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0.0
        labeled_ratio = np.sum(x[1:]) / np.sum(x) * 100

        # Format results
        result = "## Deconvolution Results\n\n"
        result += "| Derivative | Fraction |\n"
        result += "|:----------:|:--------:|\n"
        for i, frac in enumerate(x):
            bar = "█" * int(frac * 20)
            result += f"| d{i} | {frac*100:6.2f}% {bar} |\n"

        result += f"\n### Summary\n"
        result += f"- **Labeled Ratio (l.r.):** {labeled_ratio:.1f}%\n"
        result += f"- **Fit Quality (R²):** {r_squared:.4f}\n"
        result += f"- **Unlabeled (d₀):** {x[0]*100:.1f}%\n"
        result += f"- **Total labeled:** {(1-x[0])*100:.1f}%\n"

        return result

    except Exception as e:
        return f"**Error:** {str(e)}\n\nPlease check your input format."


# Example data
EXAMPLES = [
    ["100, 8.88, 0.37", "10, 20, 40, 25, 5, 0.9, 0.04", 4, 1],  # H/D exchange
    ["100, 5.5, 0.3", "80, 4.4, 20, 1.1, 0.06", 1, 2],  # 18O labeling
    ["100, 11.1, 0.6", "50, 30, 15, 5", 3, 1],  # Partial labeling
]

# Gradio Interface
with gr.Blocks(
    title="IsoPat - Isotope Pattern Deconvolution",
    theme=gr.themes.Soft(primary_hue="blue")
) as demo:

    gr.Markdown("""
    # 🧪 IsoPat 3.0
    ## Isotope Pattern Deconvolution for Mass Spectrometry

    Determine the relative amounts of isotope-labeled species (d₀, d₁, d₂, ..., dₙ)
    from mass spectrometry data using least-squares optimization.

    **Reference:** [Gruber et al. (2007) J. Org. Chem. 72, 5778-5783](https://doi.org/10.1021/jo070831o)
    """)

    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### Input")

            unlabeled = gr.Textbox(
                label="Unlabeled Pattern",
                placeholder="100, 8.88, 0.37",
                value="100, 8.88, 0.37",
                info="Natural isotope distribution: M, M+1, M+2, ..."
            )

            analyte = gr.Textbox(
                label="Analyte Pattern",
                placeholder="10, 20, 40, 25, 5, 0.9, 0.04",
                value="10, 20, 40, 25, 5, 0.9, 0.04",
                info="Measured pattern of the labeled mixture"
            )

            with gr.Row():
                n_labels = gr.Slider(
                    minimum=1, maximum=10, value=4, step=1,
                    label="Max Labels (n)",
                    info="Maximum number of isotope labels"
                )
                mass_shift = gr.Slider(
                    minimum=1, maximum=3, value=1, step=1,
                    label="Mass Shift",
                    info="1 for D/¹³C, 2 for ¹⁸O/T"
                )

            btn = gr.Button("🔬 Deconvolve", variant="primary", size="lg")

        with gr.Column(scale=1):
            gr.Markdown("### Results")
            output = gr.Markdown()

    gr.Markdown("### Examples")
    gr.Examples(
        examples=EXAMPLES,
        inputs=[unlabeled, analyte, n_labels, mass_shift],
        outputs=output,
        fn=deconvolve,
        cache_examples=True,
        examples_per_page=3
    )

    btn.click(
        deconvolve,
        inputs=[unlabeled, analyte, n_labels, mass_shift],
        outputs=output
    )

    gr.Markdown("""
    ---
    ### Installation

    ```bash
    pip install isopat
    ```

    ### Python Usage

    ```python
    from isopat import deconvolve

    unlabeled = [100, 8.88, 0.37]
    analyte = [10, 20, 40, 25, 5, 0.9, 0.04]
    result = deconvolve(unlabeled, analyte, n_labels=4)
    print(result)
    ```

    ---
    **GitHub:** [innophore/isopat](https://github.com/innophore/isopat) |
    **PyPI:** [isopat](https://pypi.org/project/isopat/) |
    **License:** MIT
    """)

if __name__ == "__main__":
    demo.launch()
